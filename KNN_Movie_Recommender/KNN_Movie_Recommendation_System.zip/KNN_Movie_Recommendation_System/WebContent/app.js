const newTable = document.querySelector('.gentable');

newTable.innerHTML = generate_table();

function generate_table() {
	var body = document.getElementsByTagName("body")[0];

	var tbl = document.createElement("table");
	var tblBody = document.createElement("tbody");

	//create table column
	for (var i = 0; i < 4; i++) {
		// creates a table row
		var row = document.createElement("tr");

		for (var j = 0; j < 2; j++) {
			var cell = document.createElement("td");
			var cellText = document.createTextNode("hello");
			cell.appendChild(cellText);
			row.appendChild(cell);
		}

		// add the row to the end of the table body
		tblBody.appendChild(row);
	}

	// put the <tbody> in the <table>
	tbl.appendChild(tblBody);
	// appends <table> into <body>
	body.appendChild(tbl);
	// sets the border attribute of tbl to 2;
	tbl.setAttribute("border", "2");
}